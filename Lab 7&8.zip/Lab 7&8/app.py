from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# API setup
API_KEY = 'c7f8a54be442d2ce457076f410730800'  # Replace with your OpenWeatherMap API key
BASE_URL = "http://api.openweathermap.org/data/2.5/weather"

# Store history in memory (could use a database for persistence)
history = []

# Weather icon mapping
WEATHER_ICONS = {
    "clear sky": "https://openweathermap.org/img/wn/01d.png",
    "few clouds": "https://openweathermap.org/img/wn/02d.png",
    "scattered clouds": "https://openweathermap.org/img/wn/03d.png",
    "broken clouds": "https://openweathermap.org/img/wn/04d.png",
    "shower rain": "https://openweathermap.org/img/wn/09d.png",
    "rain": "https://openweathermap.org/img/wn/10d.png",
    "thunderstorm": "https://openweathermap.org/img/wn/11d.png",
    "snow": "https://openweathermap.org/img/wn/13d.png",
    "mist": "https://openweathermap.org/img/wn/50d.png"
}

def get_weather(city):
    try:
        url = f"{BASE_URL}?q={city}&appid={API_KEY}&units=metric"
        response = requests.get(url)
        data = response.json()

        if response.status_code == 200:
            city_name = data["name"]
            temp = data["main"]["temp"]
            humidity = data["main"]["humidity"]
            wind_speed = data["wind"]["speed"]
            description = data["weather"][0]["description"]
            icon = WEATHER_ICONS.get(description, "https://openweathermap.org/img/wn/01d.png")

            weather_data = {
                "city": city_name,
                "temp": temp,
                "humidity": humidity,
                "wind_speed": wind_speed,
                "description": description,
                "icon": icon
            }
            history.append(f"{city_name} - {temp}°C, {description}")
            return weather_data
        return None
    except:
        return None

@app.route('/', methods=['GET', 'POST'])
def index():
    weather_data = None
    error = None
    if request.method == 'POST':
        city = request.form.get('city')
        if city:
            weather_data = get_weather(city)
            if not weather_data:
                error = "City not found or something went wrong!"
        else:
            error = "Please enter a city name!"
    
    return render_template('index.html', weather_data=weather_data, history=history, error=error)

@app.route('/clear_history', methods=['POST'])
def clear_history_route():
    global history
    history = []
    return jsonify({"status": "History cleared"})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)